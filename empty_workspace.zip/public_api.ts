export { EcaPortalComponent } from './apps/empty/src/app/modules/eca-portal/eca-portal.component';
export { EcaPortalModule } from './apps/empty/src/app/modules/eca-portal/eca-portal.module'
