"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var EcaPortalComponent = /** @class */ (function () {
    function EcaPortalComponent() {
    }
    EcaPortalComponent.prototype.ngOnInit = function () {
    };
    EcaPortalComponent.decorators = [
        { type: core_1.Component, args: [{
                    selector: 'app-eca-portal',
                    templateUrl: './eca-portal.component.html',
                    styleUrls: ['./eca-portal.component.css']
                },] },
    ];
    /** @nocollapse */
    EcaPortalComponent.ctorParameters = function () { return []; };
    return EcaPortalComponent;
}());
exports.EcaPortalComponent = EcaPortalComponent;
//# sourceMappingURL=eca-portal.component.js.map