"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var eca_portal_component_1 = require("./apps/empty/src/app/modules/eca-portal/eca-portal.component");
exports.EcaPortalComponent = eca_portal_component_1.EcaPortalComponent;
var eca_portal_module_1 = require("./apps/empty/src/app/modules/eca-portal/eca-portal.module");
exports.EcaPortalModule = eca_portal_module_1.EcaPortalModule;
//# sourceMappingURL=public_api.js.map