import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eca-portal',
  templateUrl: './eca-portal.component.html',
  styleUrls: ['./eca-portal.component.css']
})
export class EcaPortalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
